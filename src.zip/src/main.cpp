#include <bits/stdc++.h>

#include "cardsLinkedList.h"
#include "menus.h"

using namespace std;


//cardNode *head;

int main(){
	
	cardNode *head;
	
	cout<<&head<<endl;
	cout<<&(head->data)<<endl;
	cout<<&(head->data.value)<<endl;
	
	initCardsFromFiles(head);
	menu();
}
