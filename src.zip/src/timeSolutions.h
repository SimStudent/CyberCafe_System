// timeSolutions 对于时间的处理模块

#include <bits/stdc++.h>

tm * getRecentTime();
void printTime(tm *aTime);
tm * countTime(tm *aTime,tm *bTime);

