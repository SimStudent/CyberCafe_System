#include <bits/stdc++.h>
#include <windows.h>

#ifndef cardsLinkedList
#define cardsLinkedList
#endif

#include "cardsLinkedList.h"
#include "timeSolutions.h"
using namespace std;

void menu();
void menu_1();
void menu_2();
void menu_3();
void menu_4();
void menu_5();
void menu_6();
void menu_7();

void menu_11();
void menu_12();
void menu_13();

void menu_21();
void menu_22();
void menu_23();
void menu_24();

void menu_31();
void menu_32();

void menu_41();
void menu_42();

void menu_51();
void menu_52();
void menu_53();

void menu_61();
void menu_62();
void menu_63();

void menu_71();
void menu_72();

void menuPrint();
